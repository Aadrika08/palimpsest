# Palimpsest: a guided development encounter

Extract this complete ZIP and open index.html locally. No server, installation,
model download or network connection is required for this recorded encounter.
The introduction links all six modes and leaves playback under your control.
Start with One map and Borrowed body, then inspect Afterimage, listen to Choir,
and explore the structural/anatomical studies. These use different records and
models; they are not six views of one trial.

The guided introduction is not timed. Preserve the declared source durations:
60 seconds for Afterimage, 120 seconds for Choir; the four static modes have
ten-minute review sessions. Do not count this introduction as those sessions.
No source material or artwork mapping changed. See checksums.json, embedded
provenance and the retained source notices. Live lab installation, independent
operator acceptance, human listening/viewing and use declarations remain open.
Complete human-review.md after actual exposure; automated evidence is separate.

Earlier guide and source record (historical checks are scoped to their versions):

# Afterimage source-frame presentation — 22 October 2026

Open index.html locally. Afterimage now pairs each recorded response with its
original effective left-camera frame. The lossless 10-column, 60-row PNG contains
all 600 original 128×128 RGB frames, in chronological order, without resizing.
Every decoded tile was compared byte-for-byte against the hash-verified NPY and
source frame index. afterimage-frames.json identifies the layout and PNG hash.
No inference, new source recording, smoothing or aesthetic frame selection occurs.

All six artwork files are byte-identical to the previous obstacle-review package.
Their source provenance, mappings and limitations remain in this pack. The new
Afterimage presentation needs its own browser verification; prior duration checks
do not establish this changed presentation's acceptance. Human Afterimage viewing
and artistic acceptance remain pending, as do independent operator and rights/use
declarations. See human-review.md. These are artificial model responses, not
biological perception. The retained source-image files increase this derivative
pack's contents; raw NPY and simulator recordings remain local.

## Previous material and evidence

# One interruption, two traces — 22 October 2026

Open index.html locally. No model or simulator runs in this pack.

A is a public FLYNN CPU run. At tick 100 its full application state was saved.
A continued unchanged; B restored that snapshot with obstacle 0 moved to
[0.75, -0.75]. The goal, controller and eye masks were unchanged.
Parent: 375 intervals, 7.5 simulated seconds.
Branch: 279 continuation intervals, 5.58 simulated seconds.
Common post-snapshot window: 275 intervals,
5.5 simulated seconds. Full routes are retained.
The square marks B's start; blue solid is A and amber dashed is B. Both use the
same fixed axes. Overlap and early termination are retained without retry.
See routes-source.json for identities, routes-registration.json for the frozen
allocation, and routes-audit.json for coordinate and state checks. The obstacle
edit refreshes derived body position through mj_forward; the small recorded
branch-start offset is disclosed without aligning or smoothing coordinates.

This is an exploratory recorded intervention, not a controlled memory experiment,
a navigation benchmark or physical pen drawing. Source records stay local;
the derivative archive contains audited provenance, not all camera data.

Afterimage, Choir, Atlas and the specimen pair are byte-identical to the previous
human-review package. Their source notices, mappings and limitations still apply.
Afterimage uses scripted manual camera footage through a duplicated-camera model
interface. Choir is 120 seconds of mapped telemetry across 18 episodes, not
biological audio; no normalization or autoplay. Start at low listening volume.
Atlas is structural reachability only. The anatomical pair has unequal coverage
and does not establish population sex differences.

Previous automated duration checks apply only to the unchanged derivatives.
The new route duration receipts are recorded separately under this run's sessions/
and the repository report. Human viewing/listening and independent operator,
rights/use and custody declarations remain pending; see human-review.md.

Rebuild the source with scripts/record_route_material.py at efc913b using locked
dependencies and the public pinned assets, with a fresh --output directory.
The frozen allocation uses seed 0, tick 100, one obstacle edit, 300 seconds,
2 GiB aggregate storage and a 2 GiB free-space floor. No automatic retries.
Audit and packaging scripts are retained in docs/reports/route-obstacle-material-2026-10-22/.
Reruns are not guaranteed byte-identical. The earlier goal-edit study is preserved.

Both updated route views passed their automated 600-second sessions; see route-session-results.json. Human acceptance remains pending.
