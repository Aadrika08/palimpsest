# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: lab.spec.ts >> actual local manual workflow, snapshots, sequential branches, comparison and export
- Location: tests/lab.spec.ts:21:1

# Error details

```
Error: expect(locator).toBeEnabled() failed

Locator:  getByRole('button', { name: 'Step', exact: true })
Expected: enabled
Received: disabled
Timeout:  90000ms

Call log:
  - Expect "toBeEnabled" getByRole('button', { name: 'Step', exact: true }) with timeout 90000ms
  - waiting for getByRole('button', { name: 'Step', exact: true })
    183 × locator resolved to <button disabled>Step</button>
        - unexpected value "disabled"

```

```yaml
- button "Step" [disabled]
```

# Test source

```ts
  1   | import {test,expect,type Page} from '@playwright/test';
  2   | import {execFileSync} from 'node:child_process';
  3   | import {createHash} from 'node:crypto';
  4   | 
  5   | async function api(page:Page,path:string,body?:unknown){return page.evaluate(async({path,body})=>{const token=(await(await fetch('/api/v1/session')).json()).token;const response=await fetch('/api/v1'+path,{method:body===undefined?'GET':'POST',headers:{'X-Palimpsest-Session':token,'Content-Type':'application/json'},...(body===undefined?{}:{body:JSON.stringify(body)})});const value=await response.json();if(!response.ok)throw Error(`${response.status}: ${JSON.stringify(value)}`);return value;},{path,body});}
  6   | async function validPlacement(page:Page,kind:'move_goal'|'move_obstacle',different?:number[]){const id=(await page.locator('.identity').innerText()).replace('Run ','');return page.evaluate(async({id,kind,different})=>{const token=(await(await fetch('/api/v1/session')).json()).token;const headers={'X-Palimpsest-Session':token,'Content-Type':'application/json'};const state=(await(await fetch(`/api/v1/runs/${id}`,{headers})).json()).state;for(const x of [-5,-3,0,3,5])for(const y of [-5,-3,0,3,5]){if(different&&x===different[0]&&y===different[1])continue;const payload=kind==='move_goal'?{kind,xy:[x,y]}:{kind,index:0,xy:[x,y]};const result=await fetch(`/api/v1/runs/${id}/previews`,{method:'POST',headers,body:JSON.stringify({payload,expected_revision:state.revision})});if(result.ok)return[x,y];}throw Error('No valid placement in actual scenario');},{id,kind,different});}
  7   | async function fillEdit(page:Page,kind:'move_goal'|'move_obstacle',xy:number[]){await page.getByLabel('Edit',{exact:true}).selectOption(kind);await page.getByLabel('X (m)',{exact:true}).fill(String(xy[0]));await page.getByLabel('Y (m)',{exact:true}).fill(String(xy[1]));}
  8   | async function runId(page:Page){return(await page.locator('.identity').innerText()).replace('Run ','');}
  9   | async function createManual(page:Page){await page.goto('/');await expect(page.getByRole('button',{name:'Create run',exact:true})).toBeEnabled();await page.getByLabel('Scenario',{exact:true}).selectOption('sparse-navigation');await page.getByLabel('Controller',{exact:true}).selectOption('manual');await page.getByRole('button',{name:'Create run',exact:true}).click();await expect(page.getByRole('button',{name:'Step',exact:true})).toBeEnabled({timeout:90_000});return runId(page);}
  10  | 
  11  | test.afterEach(async({page},info)=>{
  12  |   if(info.status==='skipped')return;
  13  |   const cleanup=await page.evaluate(async()=>{const id=document.querySelector('.identity')?.textContent?.replace('Run ','');if(!id||! /^[0-9a-f]{32}$/.test(id))return null;const token=(await(await fetch('/api/v1/session')).json()).token;const response=await fetch(`/api/v1/runs/${id}/close`,{method:'POST',headers:{'X-Palimpsest-Session':token,'Content-Type':'application/json'},body:'{}'});return {run_id:id,http_status:response.status,response:await response.json()};});
  14  |   const body=JSON.stringify(cleanup,null,2);await info.attach('owner-close.json',{body,contentType:'application/json'});const {writeFile}=await import('node:fs/promises');await writeFile(info.outputPath('owner-close.json'),body+'\n');
  15  |   if(info.status==='passed')expect(cleanup,'Every successful actual workflow must retain an owner close response').not.toBeNull();if(!cleanup)return;expect(cleanup.http_status).toBe(200);expect(cleanup.response.run_id).toBe(cleanup.run_id);
  16  |   // A successful workflow requires a clean close. Failed tests retain the
  17  |   // already failed owner's authoritative status instead of hiding teardown.
  18  |   if(info.status==='passed')expect(cleanup.response.status).toBe('closed');else expect(['closed','failed']).toContain(cleanup.response.status);
  19  | });
  20  | 
  21  | test('actual local manual workflow, snapshots, sequential branches, comparison and export',async({page})=>{
  22  |   const browserErrors:string[]=[];page.on('pageerror',error=>browserErrors.push(error.message));
  23  |   await page.goto('/');await expect(page.getByRole('button',{name:'Create run',exact:true})).toBeEnabled();
  24  |   await page.getByLabel('Scenario',{exact:true}).selectOption('sparse-navigation');
  25  |   await page.getByLabel('Controller',{exact:true}).selectOption('manual');
  26  |   await page.getByRole('button',{name:'Create run',exact:true}).click();
  27  |   await expect(page.getByRole('button',{name:'Step',exact:true})).toBeEnabled({timeout:90_000});
  28  |   await expect(page.getByRole('img',{name:'Actual left eye policy input'})).toBeVisible();
  29  |   for(const name of ['Export SVG','Export PNG','Export bundle'])await expect(page.getByRole('button',{name,exact:true})).toBeDisabled();
  30  |   await expect(page.getByText('Close the active run before exporting.',{exact:true})).toBeVisible();
  31  |   const source=await page.locator('.identity').innerText();
  32  |   await page.getByRole('button',{name:'Start',exact:true}).click();
  33  |   await expect(page.locator('.run-heading strong')).toHaveText('running');
  34  |   await expect(page.getByRole('button',{name:'Export bundle',exact:true})).toBeDisabled();
  35  |   const manual=page.getByRole('button',{name:/Focus manual drive/});await manual.focus();await page.keyboard.down('ArrowUp');await page.waitForTimeout(150);await page.keyboard.up('ArrowUp');await page.keyboard.down('ArrowLeft');
  36  |   await page.getByLabel('Edit',{exact:true}).focus();await page.keyboard.up('ArrowLeft');
  37  |   await expect.poll(async()=>{const result=await api(page,`/runs/${source.replace('Run ','')}`);return result.state.pending_commands;}).toBe(0);
  38  |   const liveXY=await validPlacement(page,'move_obstacle');await fillEdit(page,'move_obstacle',liveXY);
  39  |   await expect(page.getByRole('button',{name:'Capture snapshot',exact:true})).toBeDisabled();
  40  |   await expect(page.getByRole('button',{name:'Preview edit',exact:true})).toBeEnabled();await page.getByRole('button',{name:'Preview edit',exact:true}).click();
  41  |   await expect(page.getByRole('button',{name:'Apply edit',exact:true})).toBeEnabled();
  42  |   const editResponse=page.waitForResponse(response=>response.url().endsWith('/commands')&&response.request().postDataJSON()?.kind==='intervene');
  43  |   await page.getByRole('button',{name:'Apply edit',exact:true}).click();const liveReceipt=await(await editResponse).json();
  44  |   await expect.poll(async()=>{const result=await api(page,`/runs/${source.replace('Run ','')}/events?after=0&limit=200`);return result.events.filter((event:any)=>event.kind==='command_applied'&&event.id===liveReceipt.id).length;}).toBe(1);
  45  |   expect((await api(page,`/runs/${source.replace('Run ','')}`)).state.phase).toBe('running');
  46  |   await page.getByRole('button',{name:'Pause',exact:true}).click();
  47  |   await expect(page.locator('.run-heading strong')).toHaveText('paused');
  48  |   // Read-only preview requests choose a valid placement from this actual world.
  49  |   const xy=await validPlacement(page,'move_goal');await fillEdit(page,'move_goal',xy);
  50  |   await page.getByRole('button',{name:'Preview edit',exact:true}).click();await expect(page.getByRole('button',{name:'Apply edit',exact:true})).toBeEnabled();await page.getByRole('button',{name:'Apply edit',exact:true}).click();await expect(page.locator('.notice')).toContainText('intervene');
  51  |   await page.getByLabel('left eye enabled',{exact:true}).uncheck();await page.getByRole('button',{name:'Apply eye mask',exact:true}).click();await page.getByRole('button',{name:'Step',exact:true}).click();await expect(page.locator('.sensors figcaption').first()).toContainText('masked');
  52  |   await expect.poll(async()=>page.getByRole('img',{name:'Actual left eye policy input'}).evaluate((image:HTMLImageElement)=>{if(!image.complete||!image.naturalWidth)return false;const canvas=document.createElement('canvas');canvas.width=image.naturalWidth;canvas.height=image.naturalHeight;const context=canvas.getContext('2d')!;context.drawImage(image,0,0);return context.getImageData(0,0,canvas.width,canvas.height).data.every((value,i)=>i%4===3||value===0);})).toBe(true);
  53  |   const branchXY=await validPlacement(page,'move_goal',xy);
  54  |   await page.getByRole('button',{name:'Capture snapshot',exact:true}).click();await expect(page.locator('.notice')).toHaveText('Snapshot captured.');
  55  |   const snapshot=await page.getByLabel('Snapshot',{exact:true}).inputValue();expect(snapshot).not.toBe('');
  56  |   // At a paused boundary blur must publish zero manual intent, even without a step.
  57  |   await manual.focus();await page.keyboard.down('ArrowUp');
  58  |   await expect.poll(async()=>page.evaluate(async()=>{const token=(await(await fetch('/api/v1/session')).json()).token;const id=document.querySelector('.identity')!.textContent!.replace('Run ','');const response=await fetch(`/api/v1/runs/${id}/events?after=0&limit=200`,{headers:{'X-Palimpsest-Session':token}});const events=(await response.json()).events;const latest=events.filter((x:any)=>x.kind==='command_received'&&x.command.kind==='set_action').at(-1);return events.some((x:any)=>x.kind==='command_applied'&&x.id===latest?.command.id)?latest.command.payload.action:null;})).toEqual([1,0]);
  59  |   await page.getByRole('button',{name:'Capture snapshot',exact:true}).focus();await page.keyboard.up('ArrowUp');
  60  |   await expect.poll(async()=>page.evaluate(async()=>{const token=(await(await fetch('/api/v1/session')).json()).token;const id=document.querySelector('.identity')!.textContent!.replace('Run ','');const response=await fetch(`/api/v1/runs/${id}/events?after=0&limit=200`,{headers:{'X-Palimpsest-Session':token}});const events=(await response.json()).events;const commands=events.filter((x:any)=>x.kind==='command_received'&&x.command.kind==='set_action');const latest=commands.at(-1);return events.some((x:any)=>x.kind==='command_applied'&&x.id===latest?.command.id)?latest.command.payload.action:null;})).toEqual([0,0]);
  61  |   await page.reload();await expect(page.getByRole('button',{name:'Step',exact:true})).toBeEnabled({timeout:90_000});await expect(page.locator('.identity')).toHaveText(source);
  62  |   await page.getByRole('button',{name:'Close run',exact:true}).click();
  63  |   const branches:string[]=[];
  64  |   for(let i=0;i<2;i++){
  65  |     if(i===1){await fillEdit(page,'move_goal',branchXY);await page.getByLabel('Include the current world edit',{exact:true}).check();}
> 66  |     await page.getByLabel('Snapshot',{exact:true}).selectOption(snapshot);await page.getByRole('button',{name:'Start branch',exact:true}).click();await expect(page.getByRole('button',{name:'Step',exact:true})).toBeEnabled({timeout:90_000});
      |                                                                                                                                                                                                                   ^ Error: expect(locator).toBeEnabled() failed
  67  |     branches.push((await page.locator('.identity').innerText()).replace('Run ',''));
  68  |     for(let tick=0;tick<3;tick++){const before=await page.locator('.run-heading').innerText();await page.getByRole('button',{name:'Step',exact:true}).click();await expect.poll(()=>page.locator('.run-heading').innerText()).not.toBe(before);}
  69  |     await page.getByRole('button',{name:'Close run',exact:true}).click();
  70  |   }
  71  |   expect(branches[0]).not.toBe(branches[1]);expect(source).not.toContain(branches[0]);
  72  |   await page.getByLabel('Left run',{exact:true}).selectOption(branches[0]);await page.getByLabel('Right run',{exact:true}).selectOption(branches[1]);await page.getByRole('button',{name:'Compare runs',exact:true}).click();await expect(page.getByText('Provenance differences — inspect before overlays',{exact:true})).toBeVisible();await expect(page.locator('.comparison svg')).toBeVisible();
  73  |   const compared=await api(page,`/compare?left=${branches[0]}&right=${branches[1]}`);expect(compared.left.worlds[0].world.goal.slice(0,2)).toEqual(xy);expect(compared.right.worlds[0].world.goal.slice(0,2)).toEqual(branchXY);expect(compared.left.events.some((event:any)=>event.kind==='intervention')).toBe(false);expect(compared.right.events.some((event:any)=>event.kind==='intervention')).toBe(true);
  74  |   await page.getByLabel('Recorded run',{exact:true}).selectOption(branches[0]);await page.getByRole('button',{name:'Recorded playback',exact:true}).click();await expect(page.locator('.mode')).toHaveText('Recorded playback');await expect(page.getByRole('button',{name:'Step',exact:true})).toBeDisabled();
  75  |   const downloading=page.waitForEvent('download');await page.getByRole('button',{name:'Export SVG',exact:true}).click();const artifact=await downloading;expect(artifact.suggestedFilename()).toMatch(/\.svg$/);expect(await artifact.failure()).toBeNull();
  76  |   await page.screenshot({path:'test-results/actual-lab-desktop.png',fullPage:true});await page.setViewportSize({width:390,height:844});await expect(page.getByRole('button',{name:'Recorded playback',exact:true})).toBeVisible();expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBe(true);await page.screenshot({path:'test-results/actual-lab-mobile.png',fullPage:true});
  77  |   expect(browserErrors).toEqual([]);
  78  | });
  79  | 
  80  | test('actual replay jobs recover without samples and expose controls, reports and authenticated bundle',async({page,context})=>{
  81  |   const browserErrors:string[]=[];page.on('pageerror',error=>browserErrors.push(error.message));
  82  |   const source=await createManual(page);await page.getByRole('button',{name:'Start',exact:true}).click();
  83  |   await expect.poll(async()=>Number((await api(page,`/runs/${source}`)).state.total_tick),{timeout:90_000}).toBeGreaterThanOrEqual(220);
  84  |   await page.getByRole('button',{name:'Pause',exact:true}).click();await expect(page.locator('.run-heading strong')).toHaveText('paused');
  85  |   const sourceTicks=(await api(page,`/runs/${source}`)).state.total_tick;
  86  |   await page.getByRole('button',{name:'Close run',exact:true}).click();await page.getByLabel('Recorded run',{exact:true}).selectOption(source);
  87  |   await page.getByRole('button',{name:'Action replay',exact:true}).click();await expect(page.locator('.mode')).toHaveText('Action replay');
  88  |   await expect(page.locator('.run-heading strong')).toHaveText('running',{timeout:90_000});const actions=await runId(page);expect(actions).not.toBe(source);
  89  |   await page.getByRole('button',{name:'Pause',exact:true}).click();await expect(page.locator('.run-heading strong')).toHaveText('paused');
  90  |   for(const name of ['Step','Reset','Preview edit','Apply edit','Capture snapshot','Apply eye mask','Export SVG','Export PNG','Export bundle'])await expect(page.getByRole('button',{name,exact:true})).toBeDisabled();
  91  |   await expect(page.getByRole('button',{name:/Focus manual drive/})).toBeDisabled();await expect(page.getByRole('img',{name:'Actual left eye policy input'})).toHaveCount(0);
  92  |   const token=(await api(page,'/session')).token;
  93  |   await page.getByRole('button',{name:'Start',exact:true}).click();await expect(page.locator('.run-heading strong')).toHaveText('running');await page.goto('about:blank');
  94  |   const outsideStatus=async()=>{const response=await context.request.get(`/api/v1/runs/${actions}`,{headers:{'X-Palimpsest-Session':token}});expect(response.ok()).toBe(true);return response.json();};
  95  |   await expect.poll(async()=>(await outsideStatus()).jobstate).toBe('paused');const pausedTick=(await outsideStatus()).state.total_tick;
  96  |   await page.goto('/');await expect(page.locator('.connection')).toContainText('Local stream connected',{timeout:15_000});await expect(page.locator('.run-heading strong')).toHaveText('paused');
  97  |   await page.reload();await expect(page.locator('.identity')).toHaveText(`Run ${actions}`,{timeout:15_000});await expect(page.locator('.mode')).toHaveText('Action replay');await expect(page.locator('.run-heading strong')).toHaveText('paused');await expect(page.locator('.profile-line')).toContainText('sparse-navigation');
  98  |   await page.waitForTimeout(350);expect((await api(page,`/runs/${actions}`)).state.total_tick).toBe(pausedTick);
  99  |   await expect(page.getByRole('button',{name:'Preview edit',exact:true})).toBeDisabled();
  100 |   await page.screenshot({path:'test-results/actual-replay-paused.png',fullPage:true});
  101 |   await page.getByRole('button',{name:'Start',exact:true}).click();await expect(page.locator('.run-heading strong')).toHaveText('completed',{timeout:90_000});
  102 |   const actionReport=page.locator('.inspector details').filter({has:page.getByText('Replay verification result',{exact:true})}).locator('pre');await expect(actionReport).toContainText('"status": "passed"');
  103 |   const actionResult=JSON.parse(await actionReport.innerText());expect(actionResult.mode).toBe('actions');expect(actionResult.compared_ticks).toBe(sourceTicks);expect(actionResult.controller_reexecuted).toBe(false);
  104 |   await page.getByLabel('Recorded run',{exact:true}).selectOption('');
  105 |   const artifactRequests:string[]=[];page.on('request',request=>{if(request.url().includes('/artifacts/')){expect(request.url()).not.toMatch(/token|session=/);expect(request.headers()['x-palimpsest-session']).toBeTruthy();artifactRequests.push(request.url());}});
  106 |   await expect(page.getByRole('button',{name:'Export bundle',exact:true})).toBeEnabled();
  107 |   let released=false;page.on('response',response=>{if(response.url().endsWith(`/runs/${actions}/close`)&&response.status()===200)released=true;});page.on('request',request=>{if(request.url().endsWith(`/runs/${actions}/exports`))expect(released).toBe(true);});
  108 |   const downloading=page.waitForEvent('download');await page.getByRole('button',{name:'Export bundle',exact:true}).click();const artifact=await downloading;expect(await artifact.failure()).toBeNull();expect(artifact.suggestedFilename()).toContain(actions);const downloadPath=await artifact.path();expect(downloadPath).toBeTruthy();
  109 |   const bundle=JSON.parse(execFileSync('python',['-c',"import hashlib,json,sys,zipfile; z=zipfile.ZipFile(sys.argv[1]); m=json.loads(z.read('bundle-manifest.json')); assert all(hashlib.sha256(z.read(f['path'])).hexdigest()==f['sha256'] for f in m['files']); print(json.dumps({'names':z.namelist(),'report':json.loads(z.read('replay-report.json'))}))",downloadPath!],{encoding:'utf8'}));expect(bundle.names).toContain('job-events.jsonl');expect(bundle.report.status).toBe('passed');expect(artifactRequests.length).toBeGreaterThan(0);
  110 |   await page.getByLabel('Recorded run',{exact:true}).selectOption(source);await page.getByRole('button',{name:'Policy replay',exact:true}).click();await expect(page.locator('.mode')).toHaveText('Policy replay');await expect(page.locator('.run-heading strong')).toHaveText('completed',{timeout:90_000});
  111 |   const policyResult=JSON.parse(await actionReport.innerText());expect(policyResult.mode).toBe('policy');expect(policyResult.status).toBe('passed');expect(policyResult.controller_reexecuted).toBe(true);expect(policyResult.compared_ticks).toBe(sourceTicks);await expect(page.locator('.profile-line')).toContainText('sparse-navigation');
  112 |   await expect(page.locator('.error')).toHaveCount(0);await page.screenshot({path:'test-results/actual-replay-completed.png',fullPage:true});
  113 |   await page.getByRole('button',{name:'Action replay',exact:true}).click();await expect(page.locator('.run-heading strong')).toHaveText('running',{timeout:90_000});await page.getByRole('button',{name:'Pause',exact:true}).click();await expect(page.locator('.run-heading strong')).toHaveText('paused');
  114 |   await page.getByRole('button',{name:'Stop',exact:true}).click();await expect(page.locator('.run-heading strong')).toHaveText('canceled',{timeout:90_000});await expect(actionReport).toContainText('"status": "cancelled"');
  115 |   expect(browserErrors).toEqual([]);expect(await page.locator('.error').count()).toBe(0);
  116 | });
  117 | 
  118 | test('actual trajectory overlay isolation and keyboard error recovery',async({page})=>{
  119 |   const id=await createManual(page);await expect(page.locator('.notice')).not.toContainText('Loading run');
  120 |   await page.getByRole('button',{name:'Step',exact:true}).focus();await page.keyboard.press('Enter');
  121 |   await expect.poll(async()=>(await api(page,`/runs/${id}`)).state.total_tick).toBe(1);
  122 |   const before=await api(page,`/runs/${id}`);const eventsBefore=await api(page,`/runs/${id}/events?after=0&limit=200`);
  123 |   const mutations:string[]=[];page.on('request',request=>{if(request.url().includes('/api/')&&!['GET','HEAD'].includes(request.method()))mutations.push(request.method()+' '+new URL(request.url()).pathname);});
  124 |   const toggle=page.getByLabel('Show trajectory overlays',{exact:true});await toggle.focus();await page.keyboard.press('Space');await expect(toggle).not.toBeChecked();await expect(page.locator('[data-overlay="trajectory"]')).toHaveCount(0);await page.keyboard.press('Space');await expect(toggle).toBeChecked();await expect(page.locator('[data-overlay="trajectory"]')).toHaveCount(1);
  125 |   expect(await toggle.evaluate(element=>getComputedStyle(element).outlineWidth)).toBe('3px');
  126 |   const after=await api(page,`/runs/${id}`);expect(after.sample.inputs).toEqual(before.sample.inputs);expect(after.sample.transition).toEqual(before.sample.transition);expect(after.state).toEqual(before.state);expect(await api(page,`/runs/${id}/events?after=0&limit=200`)).toEqual(eventsBefore);expect(mutations).toEqual([]);
  127 |   await page.getByLabel('X (m)',{exact:true}).fill('100');await page.getByRole('button',{name:'Preview edit',exact:true}).focus();await page.keyboard.press('Enter');await expect(page.getByRole('alert')).toBeVisible();await expect(page.getByRole('alert')).toBeFocused();await page.keyboard.press('Tab');await expect(page.getByRole('button',{name:'Dismiss error',exact:true})).toBeFocused();await page.keyboard.press('Enter');await expect(page.getByRole('alert')).toHaveCount(0);await expect(page.getByRole('button',{name:'Preview edit',exact:true})).toBeFocused();expect((await api(page,`/runs/${id}`)).state).toEqual(before.state);
  128 |   await page.getByRole('link',{name:'Skip to run controls',exact:true}).focus();await page.keyboard.press('Enter');await expect(page.getByRole('navigation',{name:'Run controls',exact:true})).toBeFocused();
  129 | });
  130 | 
  131 | test('actual memory inspector, U-only branch and evidence-linked route annotations',async({page})=>{
  132 |   const browserErrors:string[]=[];page.on('pageerror',error=>browserErrors.push(error.message));
  133 |   await page.goto('/');await expect(page.getByRole('button',{name:'Create run',exact:true})).toBeEnabled();
  134 |   await page.getByLabel('Controller',{exact:true}).selectOption('teacher');
  135 |   await page.getByLabel('Scenario',{exact:true}).selectOption('memory-passages');
  136 |   await expect(page.getByLabel('Controller',{exact:true})).toHaveValue('manual');
  137 |   await expect(page.getByLabel('Controller',{exact:true}).locator('option[value="teacher"]')).toHaveJSProperty('disabled',true);
  138 |   await page.getByRole('button',{name:'Create run',exact:true}).click();
  139 |   await expect(page.getByRole('button',{name:'Step',exact:true})).toBeEnabled({timeout:90_000});
  140 |   const source=await runId(page);await expect(page.getByRole('region',{name:'Artificial memory'})).toBeVisible();
  141 |   await expect(page.locator('.input-stage')).toContainText('bearing will be selected');
  142 |   for(let tick=0;tick<8;tick++){
  143 |     await page.getByRole('button',{name:'Step',exact:true}).click();
  144 |     await expect.poll(async()=>(await api(page,`/runs/${source}`)).state.total_tick).toBe(tick+1);
  145 |   }
  146 |   await page.getByRole('button',{name:'Capture snapshot',exact:true}).click();
  147 |   await expect(page.locator('.notice')).toHaveText('Snapshot captured.');
  148 |   await page.getByRole('button',{name:'Use displayed U',exact:true}).click();
  149 |   await expect(page.getByRole('button',{name:'Start U-only branch',exact:true})).toBeDisabled();
  150 |   const before=await api(page,`/runs/${source}`), u=structuredClone(before.sample.memory.u);
  151 |   u.payload={rules:[{relation:'local_cue',trigger:'cue_changed'}],version:1,vocabulary:'passage-relations-v1'};
  152 |   u.provenance.method='hand-authored-v1';u.payload_sha256=createHash('sha256').update(JSON.stringify(u.payload)).digest('hex');
  153 |   await page.getByRole('button',{name:'Close run',exact:true}).click();
  154 |   await page.getByLabel('U artifact JSON',{exact:true}).setInputFiles({name:'invalid.json',mimeType:'application/json',buffer:Buffer.from('{}')});
  155 |   await expect(page.getByText('invalid.json',{exact:true})).toBeVisible();
  156 |   const count=(await api(page,'/runs')).runs.length;
  157 |   await page.getByRole('button',{name:'Start U-only branch',exact:true}).click();
  158 |   await expect(page.getByRole('alert')).toBeVisible();
  159 |   expect((await api(page,'/runs')).runs.length).toBe(count);
  160 |   await page.getByRole('button',{name:'Dismiss error',exact:true}).click();
  161 |   await page.getByLabel('U artifact JSON',{exact:true}).setInputFiles({name:'authored-local.json',mimeType:'application/json',buffer:Buffer.from(JSON.stringify(u))});
  162 |   await expect(page.getByText('authored-local.json',{exact:true})).toBeVisible();
  163 |   await page.getByRole('button',{name:'Start U-only branch',exact:true}).click();
  164 |   await expect(page.getByRole('button',{name:'Step',exact:true})).toBeEnabled({timeout:90_000});
  165 |   const branch=await runId(page);expect(branch).not.toBe(source);
  166 |   await expect.poll(async()=>(await api(page,`/runs/${branch}`)).sample?.memory?.tick).toBe(7);
```